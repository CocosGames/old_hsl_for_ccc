require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"HSL_Frag":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ec734TCvl1HD6/WPgc+QJw/', 'HSL_Frag');
// SpriteHSL\HSL_Frag.js

module.exports = "\n#ifdef GL_ES  \nprecision mediump float;  \n#endif  \n  \nvarying vec2 v_texCoord;  \nuniform float u_dH;  \nuniform float u_dS;  \nuniform float u_dL;  \n  \nvoid main() {  \n\n    vec4 texColor=texture2D(CC_Texture0, v_texCoord).rgba;\n    float r=texColor.r;\n    float g=texColor.g;\n    float b=texColor.b;\n    float a=texColor.a;\n    float h;  \n    float s;  \n    float l;  \n    {  \n        float max=max(max(r,g),b);  \n        float min=min(min(r,g),b);  \n\n        if(max==min){  \n  \n            h=0.0;  \n        }else if(max==r&&g>=b){  \n            h=60.0*(g-b)/(max-min)+0.0;  \n        }else if(max==r&&g<b){  \n            h=60.0*(g-b)/(max-min)+360.0;  \n        }else if(max==g){  \n            h=60.0*(b-r)/(max-min)+120.0;  \n        }else if(max==b){  \n            h=60.0*(r-g)/(max-min)+240.0;  \n        }  \n\n        l=0.5*(max+min);  \n\n        if(l==0.0||max==min){  \n            s=0.0;  \n        }else if(0.0<=l&&l<=0.5){  \n            s=(max-min)/(2.0*l);  \n        }else if(l>0.5){  \n            s=(max-min)/(2.0-2.0*l);  \n        }  \n    }  \n\n    h=h+u_dH;  \n    s=min(1.0,max(0.0,s+u_dS));  \n\n\n    vec4 finalColor;  \n    {  \n        float q;  \n        if(l<0.5){  \n            q=l*(1.0+s);  \n        }else if(l>=0.5){  \n            q=l+s-l*s;  \n        }  \n        float p=2.0*l-q;  \n        float hk=h/360.0;  \n        float t[3];  \n        t[0]=hk+1.0/3.0;t[1]=hk;t[2]=hk-1.0/3.0;  \n        for(int i=0;i<3;i++){  \n            if(t[i]<0.0)t[i]+=1.0;  \n            if(t[i]>1.0)t[i]-=1.0;  \n        }\n        float c[3];  \n        for(int i=0;i<3;i++){  \n            if(t[i]<1.0/6.0){  \n                c[i]=p+((q-p)*6.0*t[i]);  \n            }else if(1.0/6.0<=t[i]&&t[i]<0.5){  \n                c[i]=q;  \n            }else if(0.5<=t[i]&&t[i]<2.0/3.0){  \n                c[i]=p+((q-p)*6.0*(2.0/3.0-t[i]));  \n            }else{  \n                c[i]=p;  \n            }  \n        }  \n        finalColor=vec4(c[0],c[1],c[2],a);  \n    }  \n  \n    finalColor+=vec4(u_dL,u_dL,u_dL,0.0);  \n  \n    gl_FragColor=finalColor;  \n  \n}  \n";

cc._RFpop();
},{}],"HSL_Vert":[function(require,module,exports){
"use strict";
cc._RFpush(module, '14526g+YXlPiYcyjlnm5sp2', 'HSL_Vert');
// SpriteHSL\HSL_Vert.js

module.exports = "\nattribute vec4 a_position;\n attribute vec2 a_texCoord;\n attribute vec4 a_color;\n varying vec2 v_texCoord;\n varying vec4 v_fragmentColor;\n void main()\n {\n     gl_Position = CC_PMatrix  * a_position;\n     v_fragmentColor = a_color;\n     v_texCoord = a_texCoord;\n }\n";

cc._RFpop();
},{}],"Sprite_HSL":[function(require,module,exports){
"use strict";
cc._RFpush(module, '201aaD4xtJMSJ3upAS2UopN', 'Sprite_HSL');
// SpriteHSL\Sprite_HSL.js

var _vert = require("HSL_Vert");
var _frag = require("HSL_Frag");

var SpriteHSL = cc.Class({
    "extends": cc.Component,

    properties: {
        dH: {
            "default": 0,
            type: cc.Integer,
            range: [0, 360, 1],
            slide: true
        },
        dS: {
            "default": 0,
            type: cc.Integer,
            range: [-1, 1, 0.01],
            slide: true
        },
        dL: {
            "default": 0,
            type: cc.Integer,
            range: [-1, 1, 0.01],
            slide: true
        },
        // affectChildren: {
        //     default: true,
        //     notify: function () {

        //     }
        // },
        previewId: {
            "default": null,
            editorOnly: true,
            visible: false
        },
        _program: {
            "default": null,
            visible: false
        }
    },

    onLoad: function onLoad() {
        this.render(this.dH, this.dS, this.dL, false);
    },

    editor: {
        requireComponent: cc.Sprite,
        executeInEditMode: true
    },

    onFocusInEditor: function onFocusInEditor() {
        if (this.previewId != null) clearInterval(this.previewId);
        var self = this;
        this.previewId = setInterval(function () {
            self.render(self.dH, self.dS, self.dL, false);
        }, 1 / 60);
    },

    onLostFocusInEditor: function onLostFocusInEditor() {
        if (this.previewId != null) clearInterval(this.previewId);
    },

    onDestroy: function onDestroy() {
        if (this.previewId != null) clearInterval(this.previewId);
        this.dH = this.dL = this.dS = 0;
        this.render(this.dH, this.dS, this.dL, false);
    },

    render: function render(h, s, l, enforce) {
        if (!this._program) this._program = new cc.GLProgram();
        if (cc.sys.isNative) {
            this._program.initWithString(_vert, _frag);
            this._program.link();
            this._program.updateUniforms();
            var glProgram_state = cc.GLProgramState.getOrCreateWithGLProgram(this._program);
            glProgram_state.setUniformFloat("u_dH", h);
            glProgram_state.setUniformFloat("u_dS", s);
            glProgram_state.setUniformFloat("u_dL", l);
        } else {
            this._program.initWithVertexShaderByteArray(_vert, _frag);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_POSITION, cc.macro.VERTEX_ATTRIB_POSITION);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_COLOR, cc.macro.VERTEX_ATTRIB_COLOR);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_TEX_COORD, cc.macro.VERTEX_ATTRIB_TEX_COORDS);
            this._program.link();
            this._program.updateUniforms();
            this._program.setUniformLocationWith1f(this._program.getUniformLocationForName("u_dH"), h);
            this._program.setUniformLocationWith1f(this._program.getUniformLocationForName("u_dS"), s);
            this._program.setUniformLocationWith1f(this._program.getUniformLocationForName("u_dL"), l);
        }
        this.setProgram(this.node._sgNode, this._program, enforce);
    },

    setProgram: function setProgram(node, program, enforce) {

        if (cc.sys.isNative) {
            var glProgram_state = cc.GLProgramState.getOrCreateWithGLProgram(program);
            node.setGLProgramState(glProgram_state);
        } else {
            node.setShaderProgram(program);
        }

        var children = node.children;
        if (!children) return;
        for (var i = 0; i < children.length; i++) {
            this.setProgram(children[i], program);
        }
    }
});

cc._RFpop();
},{"HSL_Frag":"HSL_Frag","HSL_Vert":"HSL_Vert"}]},{},["HSL_Vert","Sprite_HSL","HSL_Frag"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkQ6L0NvY29zQ3JlYXRvci9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImFzc2V0cy9TcHJpdGVIU0wvSFNMX0ZyYWcuanMiLCJhc3NldHMvU3ByaXRlSFNML0hTTF9WZXJ0LmpzIiwiYXNzZXRzL1Nwcml0ZUhTTC9TcHJpdGVfSFNMLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2VjNzM0VEN2bDFIRDYvV1BnYytRSncvJywgJ0hTTF9GcmFnJyk7XG4vLyBTcHJpdGVIU0xcXEhTTF9GcmFnLmpzXG5cbm1vZHVsZS5leHBvcnRzID0gXCJcXG4jaWZkZWYgR0xfRVMgIFxcbnByZWNpc2lvbiBtZWRpdW1wIGZsb2F0OyAgXFxuI2VuZGlmICBcXG4gIFxcbnZhcnlpbmcgdmVjMiB2X3RleENvb3JkOyAgXFxudW5pZm9ybSBmbG9hdCB1X2RIOyAgXFxudW5pZm9ybSBmbG9hdCB1X2RTOyAgXFxudW5pZm9ybSBmbG9hdCB1X2RMOyAgXFxuICBcXG52b2lkIG1haW4oKSB7ICBcXG5cXG4gICAgdmVjNCB0ZXhDb2xvcj10ZXh0dXJlMkQoQ0NfVGV4dHVyZTAsIHZfdGV4Q29vcmQpLnJnYmE7XFxuICAgIGZsb2F0IHI9dGV4Q29sb3IucjtcXG4gICAgZmxvYXQgZz10ZXhDb2xvci5nO1xcbiAgICBmbG9hdCBiPXRleENvbG9yLmI7XFxuICAgIGZsb2F0IGE9dGV4Q29sb3IuYTtcXG4gICAgZmxvYXQgaDsgIFxcbiAgICBmbG9hdCBzOyAgXFxuICAgIGZsb2F0IGw7ICBcXG4gICAgeyAgXFxuICAgICAgICBmbG9hdCBtYXg9bWF4KG1heChyLGcpLGIpOyAgXFxuICAgICAgICBmbG9hdCBtaW49bWluKG1pbihyLGcpLGIpOyAgXFxuXFxuICAgICAgICBpZihtYXg9PW1pbil7ICBcXG4gIFxcbiAgICAgICAgICAgIGg9MC4wOyAgXFxuICAgICAgICB9ZWxzZSBpZihtYXg9PXImJmc+PWIpeyAgXFxuICAgICAgICAgICAgaD02MC4wKihnLWIpLyhtYXgtbWluKSswLjA7ICBcXG4gICAgICAgIH1lbHNlIGlmKG1heD09ciYmZzxiKXsgIFxcbiAgICAgICAgICAgIGg9NjAuMCooZy1iKS8obWF4LW1pbikrMzYwLjA7ICBcXG4gICAgICAgIH1lbHNlIGlmKG1heD09Zyl7ICBcXG4gICAgICAgICAgICBoPTYwLjAqKGItcikvKG1heC1taW4pKzEyMC4wOyAgXFxuICAgICAgICB9ZWxzZSBpZihtYXg9PWIpeyAgXFxuICAgICAgICAgICAgaD02MC4wKihyLWcpLyhtYXgtbWluKSsyNDAuMDsgIFxcbiAgICAgICAgfSAgXFxuXFxuICAgICAgICBsPTAuNSoobWF4K21pbik7ICBcXG5cXG4gICAgICAgIGlmKGw9PTAuMHx8bWF4PT1taW4peyAgXFxuICAgICAgICAgICAgcz0wLjA7ICBcXG4gICAgICAgIH1lbHNlIGlmKDAuMDw9bCYmbDw9MC41KXsgIFxcbiAgICAgICAgICAgIHM9KG1heC1taW4pLygyLjAqbCk7ICBcXG4gICAgICAgIH1lbHNlIGlmKGw+MC41KXsgIFxcbiAgICAgICAgICAgIHM9KG1heC1taW4pLygyLjAtMi4wKmwpOyAgXFxuICAgICAgICB9ICBcXG4gICAgfSAgXFxuXFxuICAgIGg9aCt1X2RIOyAgXFxuICAgIHM9bWluKDEuMCxtYXgoMC4wLHMrdV9kUykpOyAgXFxuXFxuXFxuICAgIHZlYzQgZmluYWxDb2xvcjsgIFxcbiAgICB7ICBcXG4gICAgICAgIGZsb2F0IHE7ICBcXG4gICAgICAgIGlmKGw8MC41KXsgIFxcbiAgICAgICAgICAgIHE9bCooMS4wK3MpOyAgXFxuICAgICAgICB9ZWxzZSBpZihsPj0wLjUpeyAgXFxuICAgICAgICAgICAgcT1sK3MtbCpzOyAgXFxuICAgICAgICB9ICBcXG4gICAgICAgIGZsb2F0IHA9Mi4wKmwtcTsgIFxcbiAgICAgICAgZmxvYXQgaGs9aC8zNjAuMDsgIFxcbiAgICAgICAgZmxvYXQgdFszXTsgIFxcbiAgICAgICAgdFswXT1oaysxLjAvMy4wO3RbMV09aGs7dFsyXT1oay0xLjAvMy4wOyAgXFxuICAgICAgICBmb3IoaW50IGk9MDtpPDM7aSsrKXsgIFxcbiAgICAgICAgICAgIGlmKHRbaV08MC4wKXRbaV0rPTEuMDsgIFxcbiAgICAgICAgICAgIGlmKHRbaV0+MS4wKXRbaV0tPTEuMDsgIFxcbiAgICAgICAgfVxcbiAgICAgICAgZmxvYXQgY1szXTsgIFxcbiAgICAgICAgZm9yKGludCBpPTA7aTwzO2krKyl7ICBcXG4gICAgICAgICAgICBpZih0W2ldPDEuMC82LjApeyAgXFxuICAgICAgICAgICAgICAgIGNbaV09cCsoKHEtcCkqNi4wKnRbaV0pOyAgXFxuICAgICAgICAgICAgfWVsc2UgaWYoMS4wLzYuMDw9dFtpXSYmdFtpXTwwLjUpeyAgXFxuICAgICAgICAgICAgICAgIGNbaV09cTsgIFxcbiAgICAgICAgICAgIH1lbHNlIGlmKDAuNTw9dFtpXSYmdFtpXTwyLjAvMy4wKXsgIFxcbiAgICAgICAgICAgICAgICBjW2ldPXArKChxLXApKjYuMCooMi4wLzMuMC10W2ldKSk7ICBcXG4gICAgICAgICAgICB9ZWxzZXsgIFxcbiAgICAgICAgICAgICAgICBjW2ldPXA7ICBcXG4gICAgICAgICAgICB9ICBcXG4gICAgICAgIH0gIFxcbiAgICAgICAgZmluYWxDb2xvcj12ZWM0KGNbMF0sY1sxXSxjWzJdLGEpOyAgXFxuICAgIH0gIFxcbiAgXFxuICAgIGZpbmFsQ29sb3IrPXZlYzQodV9kTCx1X2RMLHVfZEwsMC4wKTsgIFxcbiAgXFxuICAgIGdsX0ZyYWdDb2xvcj1maW5hbENvbG9yOyAgXFxuICBcXG59ICBcXG5cIjtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzE0NTI2ZytZWGxQaVljeWpsbm01c3AyJywgJ0hTTF9WZXJ0Jyk7XG4vLyBTcHJpdGVIU0xcXEhTTF9WZXJ0LmpzXG5cbm1vZHVsZS5leHBvcnRzID0gXCJcXG5hdHRyaWJ1dGUgdmVjNCBhX3Bvc2l0aW9uO1xcbiBhdHRyaWJ1dGUgdmVjMiBhX3RleENvb3JkO1xcbiBhdHRyaWJ1dGUgdmVjNCBhX2NvbG9yO1xcbiB2YXJ5aW5nIHZlYzIgdl90ZXhDb29yZDtcXG4gdmFyeWluZyB2ZWM0IHZfZnJhZ21lbnRDb2xvcjtcXG4gdm9pZCBtYWluKClcXG4ge1xcbiAgICAgZ2xfUG9zaXRpb24gPSBDQ19QTWF0cml4ICAqIGFfcG9zaXRpb247XFxuICAgICB2X2ZyYWdtZW50Q29sb3IgPSBhX2NvbG9yO1xcbiAgICAgdl90ZXhDb29yZCA9IGFfdGV4Q29vcmQ7XFxuIH1cXG5cIjtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzIwMWFhRDR4dEpNU0ozdXBBUzJVb3BOJywgJ1Nwcml0ZV9IU0wnKTtcbi8vIFNwcml0ZUhTTFxcU3ByaXRlX0hTTC5qc1xuXG52YXIgX3ZlcnQgPSByZXF1aXJlKFwiSFNMX1ZlcnRcIik7XG52YXIgX2ZyYWcgPSByZXF1aXJlKFwiSFNMX0ZyYWdcIik7XG5cbnZhciBTcHJpdGVIU0wgPSBjYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgZEg6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiAwLFxuICAgICAgICAgICAgdHlwZTogY2MuSW50ZWdlcixcbiAgICAgICAgICAgIHJhbmdlOiBbMCwgMzYwLCAxXSxcbiAgICAgICAgICAgIHNsaWRlOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIGRTOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogMCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkludGVnZXIsXG4gICAgICAgICAgICByYW5nZTogWy0xLCAxLCAwLjAxXSxcbiAgICAgICAgICAgIHNsaWRlOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIGRMOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogMCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkludGVnZXIsXG4gICAgICAgICAgICByYW5nZTogWy0xLCAxLCAwLjAxXSxcbiAgICAgICAgICAgIHNsaWRlOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIC8vIGFmZmVjdENoaWxkcmVuOiB7XG4gICAgICAgIC8vICAgICBkZWZhdWx0OiB0cnVlLFxuICAgICAgICAvLyAgICAgbm90aWZ5OiBmdW5jdGlvbiAoKSB7XG5cbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfSxcbiAgICAgICAgcHJldmlld0lkOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIGVkaXRvck9ubHk6IHRydWUsXG4gICAgICAgICAgICB2aXNpYmxlOiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICBfcHJvZ3JhbToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB2aXNpYmxlOiBmYWxzZVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLnJlbmRlcih0aGlzLmRILCB0aGlzLmRTLCB0aGlzLmRMLCBmYWxzZSk7XG4gICAgfSxcblxuICAgIGVkaXRvcjoge1xuICAgICAgICByZXF1aXJlQ29tcG9uZW50OiBjYy5TcHJpdGUsXG4gICAgICAgIGV4ZWN1dGVJbkVkaXRNb2RlOiB0cnVlXG4gICAgfSxcblxuICAgIG9uRm9jdXNJbkVkaXRvcjogZnVuY3Rpb24gb25Gb2N1c0luRWRpdG9yKCkge1xuICAgICAgICBpZiAodGhpcy5wcmV2aWV3SWQgIT0gbnVsbCkgY2xlYXJJbnRlcnZhbCh0aGlzLnByZXZpZXdJZCk7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdGhpcy5wcmV2aWV3SWQgPSBzZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzZWxmLnJlbmRlcihzZWxmLmRILCBzZWxmLmRTLCBzZWxmLmRMLCBmYWxzZSk7XG4gICAgICAgIH0sIDEgLyA2MCk7XG4gICAgfSxcblxuICAgIG9uTG9zdEZvY3VzSW5FZGl0b3I6IGZ1bmN0aW9uIG9uTG9zdEZvY3VzSW5FZGl0b3IoKSB7XG4gICAgICAgIGlmICh0aGlzLnByZXZpZXdJZCAhPSBudWxsKSBjbGVhckludGVydmFsKHRoaXMucHJldmlld0lkKTtcbiAgICB9LFxuXG4gICAgb25EZXN0cm95OiBmdW5jdGlvbiBvbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLnByZXZpZXdJZCAhPSBudWxsKSBjbGVhckludGVydmFsKHRoaXMucHJldmlld0lkKTtcbiAgICAgICAgdGhpcy5kSCA9IHRoaXMuZEwgPSB0aGlzLmRTID0gMDtcbiAgICAgICAgdGhpcy5yZW5kZXIodGhpcy5kSCwgdGhpcy5kUywgdGhpcy5kTCwgZmFsc2UpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uIHJlbmRlcihoLCBzLCBsLCBlbmZvcmNlKSB7XG4gICAgICAgIGlmICghdGhpcy5fcHJvZ3JhbSkgdGhpcy5fcHJvZ3JhbSA9IG5ldyBjYy5HTFByb2dyYW0oKTtcbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5pbml0V2l0aFN0cmluZyhfdmVydCwgX2ZyYWcpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5saW5rKCk7XG4gICAgICAgICAgICB0aGlzLl9wcm9ncmFtLnVwZGF0ZVVuaWZvcm1zKCk7XG4gICAgICAgICAgICB2YXIgZ2xQcm9ncmFtX3N0YXRlID0gY2MuR0xQcm9ncmFtU3RhdGUuZ2V0T3JDcmVhdGVXaXRoR0xQcm9ncmFtKHRoaXMuX3Byb2dyYW0pO1xuICAgICAgICAgICAgZ2xQcm9ncmFtX3N0YXRlLnNldFVuaWZvcm1GbG9hdChcInVfZEhcIiwgaCk7XG4gICAgICAgICAgICBnbFByb2dyYW1fc3RhdGUuc2V0VW5pZm9ybUZsb2F0KFwidV9kU1wiLCBzKTtcbiAgICAgICAgICAgIGdsUHJvZ3JhbV9zdGF0ZS5zZXRVbmlmb3JtRmxvYXQoXCJ1X2RMXCIsIGwpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5pbml0V2l0aFZlcnRleFNoYWRlckJ5dGVBcnJheShfdmVydCwgX2ZyYWcpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5hZGRBdHRyaWJ1dGUoY2MubWFjcm8uQVRUUklCVVRFX05BTUVfUE9TSVRJT04sIGNjLm1hY3JvLlZFUlRFWF9BVFRSSUJfUE9TSVRJT04pO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5hZGRBdHRyaWJ1dGUoY2MubWFjcm8uQVRUUklCVVRFX05BTUVfQ09MT1IsIGNjLm1hY3JvLlZFUlRFWF9BVFRSSUJfQ09MT1IpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5hZGRBdHRyaWJ1dGUoY2MubWFjcm8uQVRUUklCVVRFX05BTUVfVEVYX0NPT1JELCBjYy5tYWNyby5WRVJURVhfQVRUUklCX1RFWF9DT09SRFMpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5saW5rKCk7XG4gICAgICAgICAgICB0aGlzLl9wcm9ncmFtLnVwZGF0ZVVuaWZvcm1zKCk7XG4gICAgICAgICAgICB0aGlzLl9wcm9ncmFtLnNldFVuaWZvcm1Mb2NhdGlvbldpdGgxZih0aGlzLl9wcm9ncmFtLmdldFVuaWZvcm1Mb2NhdGlvbkZvck5hbWUoXCJ1X2RIXCIpLCBoKTtcbiAgICAgICAgICAgIHRoaXMuX3Byb2dyYW0uc2V0VW5pZm9ybUxvY2F0aW9uV2l0aDFmKHRoaXMuX3Byb2dyYW0uZ2V0VW5pZm9ybUxvY2F0aW9uRm9yTmFtZShcInVfZFNcIiksIHMpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5zZXRVbmlmb3JtTG9jYXRpb25XaXRoMWYodGhpcy5fcHJvZ3JhbS5nZXRVbmlmb3JtTG9jYXRpb25Gb3JOYW1lKFwidV9kTFwiKSwgbCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXRQcm9ncmFtKHRoaXMubm9kZS5fc2dOb2RlLCB0aGlzLl9wcm9ncmFtLCBlbmZvcmNlKTtcbiAgICB9LFxuXG4gICAgc2V0UHJvZ3JhbTogZnVuY3Rpb24gc2V0UHJvZ3JhbShub2RlLCBwcm9ncmFtLCBlbmZvcmNlKSB7XG5cbiAgICAgICAgaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgdmFyIGdsUHJvZ3JhbV9zdGF0ZSA9IGNjLkdMUHJvZ3JhbVN0YXRlLmdldE9yQ3JlYXRlV2l0aEdMUHJvZ3JhbShwcm9ncmFtKTtcbiAgICAgICAgICAgIG5vZGUuc2V0R0xQcm9ncmFtU3RhdGUoZ2xQcm9ncmFtX3N0YXRlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5vZGUuc2V0U2hhZGVyUHJvZ3JhbShwcm9ncmFtKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBjaGlsZHJlbiA9IG5vZGUuY2hpbGRyZW47XG4gICAgICAgIGlmICghY2hpbGRyZW4pIHJldHVybjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy5zZXRQcm9ncmFtKGNoaWxkcmVuW2ldLCBwcm9ncmFtKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiXX0=
