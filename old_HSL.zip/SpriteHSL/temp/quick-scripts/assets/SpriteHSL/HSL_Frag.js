(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/SpriteHSL/HSL_Frag.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ec734TCvl1HD6/WPgc+QJw/', 'HSL_Frag', __filename);
// SpriteHSL/HSL_Frag.js

"use strict";

module.exports = "\n#ifdef GL_ES  \nprecision mediump float;  \n#endif  \n  \nvarying vec2 v_texCoord;  \nuniform float u_dH;  \nuniform float u_dS;  \nuniform float u_dL;  \n  \nvoid main() {  \n\n    vec4 texColor=texture2D(CC_Texture0, v_texCoord).rgba;\n    float r=texColor.r;\n    float g=texColor.g;\n    float b=texColor.b;\n    float a=texColor.a;\n    float h;  \n    float s;  \n    float l;  \n    {  \n        float max=max(max(r,g),b);  \n        float min=min(min(r,g),b);  \n\n        if(max==min){  \n  \n            h=0.0;  \n        }else if(max==r&&g>=b){  \n            h=60.0*(g-b)/(max-min)+0.0;  \n        }else if(max==r&&g<b){  \n            h=60.0*(g-b)/(max-min)+360.0;  \n        }else if(max==g){  \n            h=60.0*(b-r)/(max-min)+120.0;  \n        }else if(max==b){  \n            h=60.0*(r-g)/(max-min)+240.0;  \n        }  \n\n        l=0.5*(max+min);  \n\n        if(l==0.0||max==min){  \n            s=0.0;  \n        }else if(0.0<=l&&l<=0.5){  \n            s=(max-min)/(2.0*l);  \n        }else if(l>0.5){  \n            s=(max-min)/(2.0-2.0*l);  \n        }  \n    }  \n\n    h=h+u_dH;  \n    s=min(1.0,max(0.0,s+u_dS));  \n\n\n    vec4 finalColor;  \n    {  \n        float q;  \n        if(l<0.5){  \n            q=l*(1.0+s);  \n        }else if(l>=0.5){  \n            q=l+s-l*s;  \n        }  \n        float p=2.0*l-q;  \n        float hk=h/360.0;  \n        float t[3];  \n        t[0]=hk+1.0/3.0;t[1]=hk;t[2]=hk-1.0/3.0;  \n        for(int i=0;i<3;i++){  \n            if(t[i]<0.0)t[i]+=1.0;  \n            if(t[i]>1.0)t[i]-=1.0;  \n        }\n        float c[3];  \n        for(int i=0;i<3;i++){  \n            if(t[i]<1.0/6.0){  \n                c[i]=p+((q-p)*6.0*t[i]);  \n            }else if(1.0/6.0<=t[i]&&t[i]<0.5){  \n                c[i]=q;  \n            }else if(0.5<=t[i]&&t[i]<2.0/3.0){  \n                c[i]=p+((q-p)*6.0*(2.0/3.0-t[i]));  \n            }else{  \n                c[i]=p;  \n            }  \n        }  \n        finalColor=vec4(c[0],c[1],c[2],a);  \n    }  \n  \n    finalColor+=vec4(u_dL,u_dL,u_dL,0.0);  \n  \n    gl_FragColor=finalColor;  \n  \n}  \n";

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HSL_Frag.js.map
        